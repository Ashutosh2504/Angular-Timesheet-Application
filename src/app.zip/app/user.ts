export class User {
    public email: string;
    public token: string;
    public status: string;
    
}
