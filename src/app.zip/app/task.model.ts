//task.model.ts
export class Task{
    public id:number;
    public taskName:string;
    public date:string;

}
