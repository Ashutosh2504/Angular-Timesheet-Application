import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Router } from '@angular/router'

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private _registerUrl = "http://localhost:3000/loginusers";
  private _loginUser = "http://localhost:3000/loginuser";
  private _loginAdmin = "http://localhost:3000/loginadmin";

  constructor(private http: HttpClient, private _router: Router) { }
 
  registerUser(user)
  {
    return this.http.post<any>(this._registerUrl,user)
  }

  loginUser(userNameAndPasswordObjectInBody) 
  {
    return this.http.post<any>(this._loginUser, userNameAndPasswordObjectInBody)
  }


  loginAdmin(userNameAndPasswordObjectInBody) 
  {
    return this.http.post<any>(this._loginAdmin, userNameAndPasswordObjectInBody)
  }
  
  loggedIn() {
    return !!localStorage.getItem('token') 
      
  }
  getToken() {
    return localStorage.getItem('token')
  }

  logoutUser() {
    localStorage.removeItem('token')
    this._router.navigate(['/events'])
  }
}
