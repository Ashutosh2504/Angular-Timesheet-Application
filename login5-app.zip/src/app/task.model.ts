//task.model.ts
export class Task {

    public token: string;
    public date: string;
    public taskName: string;
    public taskCategory: string;
    public won: string;
    public duration: string;

}
